#include "Multilist.h"

Universidad *Multilist::getHead()
{
    return head;
}

void Multilist::setHead(Universidad *head)
{
    this->head = head;
}

void Multilist::insertarUniversidad()
{
}

void Multilist::insertarSede()
{
}

void Multilist::insertarPrograma()
{
}

void Multilist::insertarEstudiante(string uni,string sede, string programa)
{
    
}

void Multilist::insertarNota()
{
}

void Multilist::eliminarUniversidad()
{
}

void Multilist::eliminarSede()
{
}

void Multilist::eliminarPrograma()
{
}

void Multilist::eliminarEstudiante()
{
}

void Multilist::eliminarNota()
{
}

void Multilist::reportePersonalizado(string departamento, string universidad, string sede, string programa, string estudiante)
{
}

void Multilist::reportePersonalizado(string departamento, string universidad, string sede, string programa)
{
}

void Multilist::reportePersonalizado(string departamento, string universidad, string sede)
{
}

void Multilist::reportePersonalizado(string departamento, string universidad)
{
}

void Multilist::reportePersonalizado(string departamento)
{
}

void Multilist::reportePersonalizado()
{
}

void Multilist::topCarreraPromedio()
{
}

void Multilist::uniPromedio()
{
}

void Multilist::porcenEdades()
{
}

void Multilist::demandaCarr()
{
}

void Multilist::porcentGenero()
{
}

void Multilist::demandaArea()
{
}

void Multilist::sedesUniversidad()
{
}
